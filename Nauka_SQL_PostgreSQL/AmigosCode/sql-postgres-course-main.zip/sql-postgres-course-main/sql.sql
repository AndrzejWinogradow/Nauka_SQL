INSERT INTO person (
    first_name,
    last_name, 
    gender,
    date_of_birth) 
VALUES ('Anne', 'Smith', 'Female', DATE '1988-01-10');

