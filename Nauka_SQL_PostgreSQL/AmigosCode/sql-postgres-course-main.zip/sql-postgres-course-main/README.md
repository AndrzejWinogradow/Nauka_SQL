# SQL Beginner to Advanced Courses

## Course 1 - Relational Database and SQL Essentials
https://amigoscode.com/p/postgres
![2](https://user-images.githubusercontent.com/40702606/106382738-72bcaf80-63b9-11eb-9f0c-2355c51fcf50.png)

## Course 2 - Database Design
https://amigoscode.com/p/database-design
![3](https://user-images.githubusercontent.com/40702606/106382755-93850500-63b9-11eb-9c96-78702dcfa4f3.png)


## Course 3 - Advanced Databases
https://amigoscode.com/p/advanced-databases
![5](https://user-images.githubusercontent.com/40702606/106382760-9aac1300-63b9-11eb-81f0-cef4ce05a585.png)




